import React, {useEffect, useRef, useState} from "react";
import './index.less';

export default function ShowCards(props){
  const { cards, showMax, delay, keyCode=32, imgWidth=15 } = props;
  const [isShow, setIsShow] = useState(false)
  const [showCards, setShowCards] = useState([]);
  const inCardNum = useRef(0);
  const nowCards = useRef([]);
  const deleteShowCardsTimer = useRef();

  const renderCards = () => {
    return showCards.map(nowCard=>{
      const {card, key} = nowCard;
      return <img style={{width:(showCards.length > (showMax / 2) ? `${0.8 * imgWidth}vw` : `${imgWidth}vw`)}} id={key} key={key} src={card} alt=""/>
    })
  }

  useEffect(()=>{
    document.addEventListener('keydown',e=>{
      if(e.code === keyCode || e.keyCode === keyCode){
        setIsShow(true);
        if(nowCards.current.length < showMax){
          const newShowCards = [...nowCards.current];
          newShowCards.push(cards[inCardNum.current])
          nowCards.current = newShowCards;
          setShowCards(nowCards.current);
          if(inCardNum.current === (cards.length - 1)){
            inCardNum.current = 0;
          }else{
            inCardNum.current += 1;
          }
        }
      }
    })
  },[cards])

  useEffect(()=>{
    if(isShow){
      clearInterval(deleteShowCardsTimer.current);
      deleteShowCardsTimer.current = setInterval(()=>{
        if(nowCards.current.length > 0){
          nowCards.current.shift();
          setShowCards([...nowCards.current]);
          if(nowCards.current.length === 0){
            setIsShow(false)
          }
        }
      }, delay)
    }
  },[isShow])

  return (
    <div className="showCardsMask"  style={{display:isShow?'block':'none'}}>
      <div
        className="showCards"
        style={{width:(showCards.length > (showMax / 2) ? '50vw' : '60vw')}}
      >
        {renderCards()}
      </div>
    </div>
  )
}
